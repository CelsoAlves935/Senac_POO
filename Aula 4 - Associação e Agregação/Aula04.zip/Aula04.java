class Aula04 {
    
    public static void main(String args[]){
        
        Produto p1 = new ProdutoPerecivel("Banana", 0.80, 12, 1234, 20, 12);
        System.out.println( p1.getNome() );
        System.out.println( p1 );
        
        Caixa c1 = new Caixa();
        c1.adicionaProduto(p1);
        c1.fazCompra(50.0);
        System.out.println(c1);

        Produto arroz = new Produto( "Arroz", 38, 2, 4321 );
        Caixa c2 = new Caixa();
        c2.adicionaProduto(arroz);
        c2.fazCompra( 80 );
        System.out.println(c2);


        ProdutoPerecivel pao = new ProdutoPerecivel(
            "Pão", 1.00, 
            7, 2222, 
            15, 16);

        System.out.println("----------------");
        System.out.println(pao);
        System.out.println("Validade: " + pao.estaValido());

        Controle controle = new Controle( pao );
        controle.verificaValidade();


        ProdutoPerecivel leite = new ProdutoPerecivel(
             "Leite", 5, 
             7, 
             2222,
             12, 8);
        Controle controleLeite = new Controle(leite);
        Caixa caixaLeite = new Caixa();
        caixaLeite.adicionaProduto(leite);


        Caixa caixaCompleto = new Caixa();
        caixaCompleto.adicionaProduto(p1);
        caixaCompleto.adicionaProduto(arroz);
        caixaCompleto.adicionaProduto(leite);
        caixaCompleto.adicionaProduto(pao);
        caixaCompleto.adicionaProduto( new Produto("Feijao", 8, 2, 5555) );
        caixaCompleto.fazCompra(200);
    }

}