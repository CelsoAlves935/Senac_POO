import java.util.ArrayList;
import java.util.List;

public class Caixa {
    
    private List<Produto> produtos = new ArrayList();

    public Caixa() {}

    public void adicionaProduto(Produto produto){
        produtos.add(produto);
    }

    public double valorTotal() {
        double val = 0.0;
        for (Produto produto : produtos) {
            val += produto.getPreco();
        }
        return val;
    }

    public void fazCompra( double valor ){

        System.out.println("\n#########");

        if( valor < valorTotal() ){
            System.out.println("Valor insuficiente.");
        } else {
            for( Produto produto : produtos ){
                produto.fazCompra();
            }
        }

    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Caixa{");
        sb.append("produto=").append(produtos);
        sb.append('}');
        return sb.toString();
    }


    


}
