public class ProdutoPerecivel extends Produto {
    
    private int validade;
    private int dia;

    public ProdutoPerecivel(String nome, 
                            double precoUnitario, 
                            int quantidade, 
                            int codigoDeBarras,
                            int validade,
                            int dia) {
        super(nome, precoUnitario, quantidade, codigoDeBarras);
        this.validade = validade;
        this.dia = dia;
    }

    public boolean estaValido() {
        return this.validade >= this.dia;
    }

    public int getValidade() {
        return validade;
    }

    public void setValidade(int validade) {
        this.validade = validade;
    }

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    


    
}
