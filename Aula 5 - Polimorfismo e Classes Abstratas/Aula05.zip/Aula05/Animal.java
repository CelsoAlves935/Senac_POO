public abstract class Animal {
    private String nome;
    private int peso;
    private String especie;
    private int valorDaConsulta = 100;
    private int valorDoExame = 50;

    public Animal(String especie, String nome, int peso) {
        this.especie = especie;
        this.nome = nome;
        this.peso = peso;
    }

    public abstract void fazBarulho();
    

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getPeso() {
        return peso;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public int getValorDaConsulta() {
        return valorDaConsulta;
    }

    public void setValorDaConsulta(int valorDaConsulta) {
        this.valorDaConsulta = valorDaConsulta;
    }

    public int getValorDoExame() {
        return valorDoExame;
    }

    public void setValorDoExame(int valorDoExame) {
        this.valorDoExame = valorDoExame;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Animal{");
        sb.append("nome=").append(nome);
        sb.append(", peso=").append(peso);
        sb.append(", especie=").append(especie);
        sb.append('}');
        return sb.toString();
    }






}
