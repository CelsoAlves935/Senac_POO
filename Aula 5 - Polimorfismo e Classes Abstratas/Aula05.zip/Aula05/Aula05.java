public class Aula05 {

    public static void main(String[] args){
        Animal animal1 = new Cachorro("Belinha",16);

        System.out.println(animal1);
        animal1.fazBarulho();
        System.out.println(animal1.getValorDaConsulta());
        System.out.println(animal1.getValorDoExame());

        Animal p1 = new Pinscher();
        Animal p2 = new Pinscher("Hércules");
        Animal p3 = new Pinscher("Raimundo",5);
        System.out.println(p1);
        System.out.println(p2);
        System.out.println(p3);



        Clinica clinica = new Clinica();

        //clinica.fazOrcamento(animal1, true);

        Animal g1 = new Gato("Nata");
        //clinica.fazOrcamento(g1);


        Animal[] animais = {
            animal1,
            g1,
            p1,
            p2,
            p3,
            new Cachorro("Nemo", 5),
            new Gato("Bonita", 8),
            new ViraLata("Gukesh",13)
        };
        clinica.fazOrcamento( animais, true );




    }

}