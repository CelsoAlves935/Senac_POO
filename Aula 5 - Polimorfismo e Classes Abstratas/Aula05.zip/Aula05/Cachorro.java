public class Cachorro extends Animal {

    private int fatorPesoExame = 2;

    private int pesoReferencia = 20;
    private int adicionalCachorroPesado = 70;

    public Cachorro(String nome, int peso) {
        super("Cachorro", nome, peso);
    }

    @Override
    public void fazBarulho() {
        System.out.println("Auau!");
    }

    @Override
    public int getValorDaConsulta(){
        if( getPeso() >= pesoReferencia ){
            return super.getValorDaConsulta() + this.adicionalCachorroPesado;
        } else {
            return super.getValorDaConsulta();
        }
    }

    @Override
    public int getValorDoExame(){
        return super.getValorDoExame() + this.fatorPesoExame * getPeso();
    }
    
}
