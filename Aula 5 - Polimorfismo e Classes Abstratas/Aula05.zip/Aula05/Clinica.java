public class Clinica {
    
    public void fazOrcamento( Animal animal, boolean temExame ) {

        System.out.println("\n#################");
        System.out.println("Orçamento " + animal.getNome());
        System.out.println("Espécie: " + animal.getEspecie());
        System.out.println("Peso: " + animal.getPeso() + "kg");

        int valorTotal = 0;

        int valorDaConsulta = animal.getValorDaConsulta();
        System.out.println("Consulta: R$" + valorDaConsulta + ",00");
        valorTotal += valorDaConsulta;

        if(temExame){
            int valorDoExame = animal.getValorDoExame();
            System.out.println("Exame: R$" + valorDoExame + ",00");
            valorTotal += valorDoExame;
        }

        System.out.println("Total: R$" + valorTotal + ",00");

    }

    public void fazOrcamento( Animal animal ){
        fazOrcamento(animal, false);
    }

    public void fazOrcamento( Animal[] animais, boolean temExame ){
        for( Animal animal : animais ){
            fazOrcamento( animal, temExame );
        }
    }

    public void fazOrcamento( Animal[] animais ){
        fazOrcamento(animais,false);
    }

}
