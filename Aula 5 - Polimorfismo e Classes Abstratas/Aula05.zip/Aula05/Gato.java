public class Gato extends Animal {
    
    public Gato(String nome, int peso) {
        super("Gato", nome, peso);
    }

    public Gato(String nome) {
        super("Gato", nome, 5);
    }

    @Override
    public void fazBarulho() {
        System.out.println("Miau Miau!");
    }

    private int descontoExame = 20;
    @Override
    public int getValorDoExame(){
        return super.getValorDoExame() - this.descontoExame;
    }
    
   
    
}
