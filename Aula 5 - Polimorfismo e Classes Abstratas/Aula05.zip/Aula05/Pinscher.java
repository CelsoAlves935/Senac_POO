public class Pinscher extends Cachorro {
    public Pinscher() {
        super("SemNome", 7);
    }

    public Pinscher(String nome) {
        super(nome, 7);
    }

    public Pinscher(String nome, int peso){
        super(nome,peso);
    }
    
}
